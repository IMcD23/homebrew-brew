// swift-tools-version:4.0

import PackageDescription

let package = Package(
    name: "ibuild",
    dependencies: [
    ],
    targets: [
        .target(
            name: "ibuild",
            dependencies: []
	    ),
    ]
)
